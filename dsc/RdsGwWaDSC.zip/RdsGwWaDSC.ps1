Configuration EnableRdsGWWA
{
	param (
		[string]$MachineName = $env:COMPUTERNAME
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

		WindowsFeature RemoteDesktopGateway
		{
			Ensure = "Present"
			Name = "RDS-Gateway"
		}

		WindowsFeature RDS-WebAccess
		{
			Ensure = "Present"
			Name = "RDS-Web-Access"
		}
	}
}