Configuration EnableRdsCBLS
{
	param (
		[string]$MachineName = $env:COMPUTERNAME
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

		WindowsFeature RemoteDesktopConnectionBroker
		{
			Ensure = "Present"
			Name = "RDS-Connection-Broker"
		}

		WindowsFeature RDS-Licensing
		{
			Ensure = "Present"
			Name = "RDS-Licensing"
		}

		WindowsFeatureSet RemoteDesktopTools
		{
			Ensure = "Present"
			Name = "RSAT-RDS-Gateway"
			IncludeAllSubFeature = $true
		}
	}
}