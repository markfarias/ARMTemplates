Configuration EnableRDG
{
	param (
		[string]$MachineName = $env:COMPUTERNAME
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration
	#Import-DscResource -ModuleName ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#TimeZone Eastern
        #{
        #    IsSingleInstance = 'Yes'
        #    TimeZone = 'Eastern Standard Time'
        #}

		WindowsFeature RemoteDesktopGateway
		{
			Ensure = "Present"
			Name = "RDS-Gateway"
			IncludeAllSubFeature = $true
		}

		WindowsFeatureSet RemoteDesktopGatewayTools
		{
			Ensure = "Present"
			Name = @("RSAT-RDS-Gateway", "RSAT-NPAS")
		}
	}
}