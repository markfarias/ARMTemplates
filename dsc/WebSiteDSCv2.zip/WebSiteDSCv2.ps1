Configuration MedchartWebAuthentication
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount = 20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc

	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}

		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

		WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}

		File IisMedchartWebAuthenticationPath
		{
			DestinationPath = "F:\inetpub\wwwroot\MedchartAuthentication"
			Ensure = "Present"
			Type = "Directory"
		}
		
		xWebAppPool AddMedchartWebAuthenticationAP
		{
			Name							= "MedchartAuthentication"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebApplication AddMedchartWebAuthentication
		{
			Website				= "Default Web Site"
			Name				= "MedchartAuthentication"
			WebAppPool			= "MedchartAuthentication"
			PhysicalPath		= "F:\inetpub\wwwroot\MedchartAuthentication"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebAuthenticationAP"
		}
	}
}

Configuration MedchartWebApplication
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}

		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

		WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}

		File IisMedchartWebAppPath
		{
			DestinationPath = "F:\inetpub\wwwroot\MedchartWeb"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisMebprepPath
		{
			DestinationPath = "F:\inetpub\wwwroot\Mebprep"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisRccbtPath
		{
			DestinationPath = "F:\inetpub\wwwroot\Rccbt"
			Ensure = "Present"
			Type = "Directory"
		}
		
		xWebAppPool AddMedchartWebAP
		{
			Name							= "MedchartWeb"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebAppPool AddMebprepAP
		{
			Name							= "Mebprep"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebAppPool AddRccbtAP
		{
			Name							= "Rccbt"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Classic"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'NetworkService'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebApplication AddMedchartWebApplication
		{
			Website				= "Default Web Site"
			Name				= "MedchartWeb"
			WebAppPool			= "MedchartWeb"
			PhysicalPath		= "F:\inetpub\wwwroot\MedchartWeb"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebAP"
		}
		
		xWebApplication AddMebprepWebApplication
		{
			Website				= "Default Web Site"
			Name				= "Mebprep"
			WebAppPool			= "Mebprep"
			PhysicalPath		= "F:\inetpub\wwwroot\Mebprep"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMebprepAP"
		}
		
		xWebApplication AddRccbtApplication
		{
			Website				= "Default Web Site"
			Name				= "Rccbt"
			WebAppPool			= "Rccbt"
			PhysicalPath		= "F:\inetpub\wwwroot\Rccbt"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddRccbtAP"
		}
	}
}

Configuration MedchartInternalWebServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}
		
        WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}

		File IisMedchartWebServicesPath
		{
			DestinationPath = "F:\inetpub\wwwroot\MedchartWebServices"
			Ensure = "Present"
			Type = "Directory"
		}
		
		xWebAppPool AddMedchartWebServicesAP
		{
			Name							= "MedchartWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebApplication AddMedchartWebServices
		{
			Website				= "Default Web Site"
			Name				= "MedchartWebServices"
			WebAppPool			= "MedchartWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\MedchartWebServices"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebServicesAP"
		}	
	}
}

Configuration MedchartExternalWebServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}
		
        WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}

		File IisMedchartWebServicesPath
		{
			DestinationPath = "F:\inetpub\wwwroot\MedchartWebServices"
			Ensure = "Present"
			Type = "Directory"
		}
		
		File IisDenclassSVCPath
		{
			DestinationPath = "F:\inetpub\wwwroot\DenclassWebSvc"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisSrexchangeSVCPath
		{
			DestinationPath = "F:\inetpub\wwwroot\Srexchange"
			Ensure = "Present"
			Type = "Directory"
		}

		xWebAppPool AddMedchartWebServicesAP
		{
			Name							= "MedchartWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebAppPool AddDenclassWebSvcAP
		{
			Name							= "DenclassWebSvc"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $true
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Classic"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'NetworkService'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebAppPool AddSrexchangeAP
		{
			Name							= "Srexchange"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'NetworkService'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebApplication AddMedchartWebServices
		{
			Website				= "Default Web Site"
			Name				= "MedchartWebServices"
			WebAppPool			= "MedchartWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\MedchartWebServices"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebServicesAP"
		}
		
		xWebApplication AddDenclassWebServices
		{
			Website				= "Default Web Site"
			Name				= "DenclassWebSvc"
			WebAppPool			= "DenclassWebSvc"
			PhysicalPath		= "F:\inetpub\wwwroot\DenclassWebSvc"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddDenclassWebSvcAP"
		}
		
		xWebApplication AddSrexchangeWebServices
		{
			Website				= "Default Web Site"
			Name				= "Srexchange"
			WebAppPool			= "Srexchange"
			PhysicalPath		= "F:\inetpub\wwwroot\Srexchange"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddSrexchangeAP"
		}
	}
}

Configuration DocsServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

        WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}
		
		File IisDocsWebServicesPath
		{
			DestinationPath = "F:\inetpub\wwwroot\DOCSWS"
			Ensure = "Present"
			Type = "Directory"
		}
		
		File IisDocsUIAppPath
		{
			DestinationPath = "F:\inetpub\wwwroot\DOCS_UI"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisDocsTestingAppPath
		{
			DestinationPath = "F:\inetpub\wwwroot\DOCS_Testing"
			Ensure = "Present"
			Type = "Directory"
		}
		
		xWebAppPool AddDocsWebServicesAP
		{
			Name							= "DocsWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebAppPool AddDocsUIAppAP
		{
			Name							= "DocsUI"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebAppPool AddDocsTestingAppAP
		{
			Name							= "DocsTesting"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebApplication AddDocsWebServices
		{
			Website				= "Default Web Site"
			Name				= "DOCSWS"
			WebAppPool			= "DocsWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\DOCSWS"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddDocsWebServicesAP"
		}
		
		xWebApplication AddDocsUIApp
		{
			Website				= "Default Web Site"
			Name				= "DOCS_UI"
			WebAppPool			= "DocsUI"
			PhysicalPath		= "F:\inetpub\wwwroot\DOCS_UI"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddDocsUIAppAP"
		}
		
		xWebApplication AddDocsTestingApp
		{
			Website				= "Default Web Site"
			Name				= "DOCS_Testing"
			WebAppPool			= "DocsTesting"
			PhysicalPath		= "F:\inetpub\wwwroot\DOCS_Testing"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddDocsTestingAppAP"
		}
	}
}

Configuration EssServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

        WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}
		
		File IisEssWebServicesPath
		{
			DestinationPath = "F:\inetpub\wwwroot\Ess"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisEssBlobWebServicesPath
		{
			DestinationPath = "F:\inetpub\wwwroot\Ess.Blob"
			Ensure = "Present"
			Type = "Directory"
		}
		
		xWebAppPool AddEssWebServicesAP
		{
			Name							= "EssWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

        xWebAppPool AddEssWebServicesAP02
		{
			Name							= "EssWebServices02"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

        xWebAppPool AddEssWebServicesAP03
		{
			Name							= "EssWebServices03"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP04
		{
			Name							= "EssWebServices04"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP05
		{
			Name							= "EssWebServices05"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP06
		{
			Name							= "EssWebServices06"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP07
		{
			Name							= "EssWebServices07"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP08
		{
			Name							= "EssWebServices08"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP09
		{
			Name							= "EssWebServices09"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP10
		{
			Name							= "EssWebServices10"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP11
		{
			Name							= "EssWebServices11"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP12
		{
			Name							= "EssWebServices12"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP13
		{
			Name							= "EssWebServices13"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

        xWebAppPool AddEssWebServicesAP14
		{
			Name							= "EssWebServices14"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
        
        xWebAppPool AddEssWebServicesAP15
		{
			Name							= "EssWebServices15"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebApplication AddEssWebServices
		{
			Website				= "Default Web Site"
			Name				= "ESS"
			WebAppPool			= "EssWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP"
		}
        
		xWebApplication AddEssWebServices02
		{
			Website				= "Default Web Site"
			Name				= "ESS02"
			WebAppPool			= "EssWebServices02"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess02"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP02"
		}
        
		xWebApplication AddEssWebServices03
		{
			Website				= "Default Web Site"
			Name				= "ESS03"
			WebAppPool			= "EssWebServices03"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess03"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP03"
		}

		xWebApplication AddEssWebServices04
		{
			Website				= "Default Web Site"
			Name				= "ESS04"
			WebAppPool			= "EssWebServices04"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess04"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP04"
		}
        
		xWebApplication AddEssWebServices05
		{
			Website				= "Default Web Site"
			Name				= "ESS05"
			WebAppPool			= "EssWebServices05"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess05"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP05"
		}
        
		xWebApplication AddEssWebServices06
		{
			Website				= "Default Web Site"
			Name				= "ESS06"
			WebAppPool			= "EssWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP06"
		}
        
		xWebApplication AddEssWebServices07
		{
			Website				= "Default Web Site"
			Name				= "ESS07"
			WebAppPool			= "EssWebServices07"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess07"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP07"
		}
        
		xWebApplication AddEssWebServices08
		{
			Website				= "Default Web Site"
			Name				= "ESS08"
			WebAppPool			= "EssWebServices08"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess08"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP08"
		}
        
		xWebApplication AddEssWebServices09
		{
			Website				= "Default Web Site"
			Name				= "ESS09"
			WebAppPool			= "EssWebServices09"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess09"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP09"
		}
        
		xWebApplication AddEssWebServices10
		{
			Website				= "Default Web Site"
			Name				= "ESS10"
			WebAppPool			= "EssWebServices10"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess10"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP10"
		}
        
		xWebApplication AddEssWebServices11
		{
			Website				= "Default Web Site"
			Name				= "ESS11"
			WebAppPool			= "EssWebServices11"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess11"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP11"
		}
        
		xWebApplication AddEssWebServices12
		{
			Website				= "Default Web Site"
			Name				= "ESS12"
			WebAppPool			= "EssWebServices12"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess12"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP12"
		}
        
		xWebApplication AddEssWebServices13
		{
			Website				= "Default Web Site"
			Name				= "ESS13"
			WebAppPool			= "EssWebServices13"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess13"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP13"
		}
        
		xWebApplication AddEssWebServices14
		{
			Website				= "Default Web Site"
			Name				= "ESS14"
			WebAppPool			= "EssWebServices14"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess14"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP14"
		}
        
		xWebApplication AddEssWebServices15
		{
			Website				= "Default Web Site"
			Name				= "ESS15"
			WebAppPool			= "EssWebServices15"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess15"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP15"
		}

		xWebApplication AddEssBlobWebServices
		{
			Website				= "Default Web Site"
			Name				= "Ess.Blob"
			WebAppPool			= "EssWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess.Blob"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP"
		}
	}
}