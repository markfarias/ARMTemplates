Configuration MedchartWebAuthentication
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount = 20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc

	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}

		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

		WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}

		File IisMedchartWebAuthenticationPath
		{
			DestinationPath = "F:\inetpub\wwwroot\MedchartAuthentication"
			Ensure = "Present"
			Type = "Directory"
		}
		
		xWebAppPool AddMedchartWebAuthenticationAP
		{
			Name							= "MedchartAuthentication"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebApplication AddMedchartWebAuthentication
		{
			Website				= "Default Web Site"
			Name				= "MedchartAuthentication"
			WebAppPool			= "MedchartAuthentication"
			PhysicalPath		= "F:\inetpub\wwwroot\MedchartAuthentication"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebAuthenticationAP"
		}
	}
}

Configuration MedchartWebApplication
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}

		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

		WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}

		File IisMedchartWebAppPath
		{
			DestinationPath = "F:\inetpub\wwwroot\MedchartWeb"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisMebprepPath
		{
			DestinationPath = "F:\inetpub\wwwroot\Mebprep"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisRccbtPath
		{
			DestinationPath = "F:\inetpub\wwwroot\Rccbt"
			Ensure = "Present"
			Type = "Directory"
		}
		
		xWebAppPool AddMedchartWebAP
		{
			Name							= "MedchartWeb"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebAppPool AddMebprepAP
		{
			Name							= "Mebprep"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebAppPool AddRccbtAP
		{
			Name							= "Rccbt"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Classic"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'NetworkService'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebApplication AddMedchartWebApplication
		{
			Website				= "Default Web Site"
			Name				= "MedchartWeb"
			WebAppPool			= "MedchartWeb"
			PhysicalPath		= "F:\inetpub\wwwroot\MedchartWeb"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebAP"
		}
		
		xWebApplication AddMebprepWebApplication
		{
			Website				= "Default Web Site"
			Name				= "Mebprep"
			WebAppPool			= "Mebprep"
			PhysicalPath		= "F:\inetpub\wwwroot\Mebprep"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMebprepAP"
		}
		
		xWebApplication AddRccbtApplication
		{
			Website				= "Default Web Site"
			Name				= "Rccbt"
			WebAppPool			= "Rccbt"
			PhysicalPath		= "F:\inetpub\wwwroot\Rccbt"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddRccbtAP"
		}
	}
}

Configuration MedchartInternalWebServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}
		
        WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}

		File IisMedchartWebServicesPath
		{
			DestinationPath = "F:\inetpub\wwwroot\MedchartWebServices"
			Ensure = "Present"
			Type = "Directory"
		}
		
		xWebAppPool AddMedchartWebServicesAP
		{
			Name							= "MedchartWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebApplication AddMedchartWebServices
		{
			Website				= "Default Web Site"
			Name				= "MedchartWebServices"
			WebAppPool			= "MedchartWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\MedchartWebServices"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebServicesAP"
		}	
	}
}

Configuration MedchartExternalWebServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}
		
        WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}

		File IisMedchartWebServicesPath
		{
			DestinationPath = "F:\inetpub\wwwroot\MedchartWebServices"
			Ensure = "Present"
			Type = "Directory"
		}
		
		File IisDenclassSVCPath
		{
			DestinationPath = "F:\inetpub\wwwroot\DenclassWebSvc"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisSrexchangeSVCPath
		{
			DestinationPath = "F:\inetpub\wwwroot\Srexchange"
			Ensure = "Present"
			Type = "Directory"
		}

		xWebAppPool AddMedchartWebServicesAP
		{
			Name							= "MedchartWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebAppPool AddDenclassWebSvcAP
		{
			Name							= "DenclassWebSvc"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $true
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Classic"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'NetworkService'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebAppPool AddSrexchangeAP
		{
			Name							= "Srexchange"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'NetworkService'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebApplication AddMedchartWebServices
		{
			Website				= "Default Web Site"
			Name				= "MedchartWebServices"
			WebAppPool			= "MedchartWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\MedchartWebServices"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebServicesAP"
		}
		
		xWebApplication AddDenclassWebServices
		{
			Website				= "Default Web Site"
			Name				= "DenclassWebSvc"
			WebAppPool			= "DenclassWebSvc"
			PhysicalPath		= "F:\inetpub\wwwroot\DenclassWebSvc"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddDenclassWebSvcAP"
		}
		
		xWebApplication AddSrexchangeWebServices
		{
			Website				= "Default Web Site"
			Name				= "Srexchange"
			WebAppPool			= "Srexchange"
			PhysicalPath		= "F:\inetpub\wwwroot\Srexchange"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddSrexchangeAP"
		}
	}
}

Configuration DocsServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

        WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}
		
		File IisDocsWebServicesPath
		{
			DestinationPath = "F:\inetpub\wwwroot\DOCSWS"
			Ensure = "Present"
			Type = "Directory"
		}
		
		File IisDocsUIAppPath
		{
			DestinationPath = "F:\inetpub\wwwroot\DOCS_UI"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisDocsTestingAppPath
		{
			DestinationPath = "F:\inetpub\wwwroot\DOCS_Testing"
			Ensure = "Present"
			Type = "Directory"
		}
		
		xWebAppPool AddDocsWebServicesAP
		{
			Name							= "DocsWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebAppPool AddDocsUIAppAP
		{
			Name							= "DocsUI"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}
		
		xWebAppPool AddDocsTestingAppAP
		{
			Name							= "DocsTesting"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebApplication AddDocsWebServices
		{
			Website				= "Default Web Site"
			Name				= "DOCSWS"
			WebAppPool			= "DocsWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\DOCSWS"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddDocsWebServicesAP"
		}
		
		xWebApplication AddDocsUIApp
		{
			Website				= "Default Web Site"
			Name				= "DOCS_UI"
			WebAppPool			= "DocsUI"
			PhysicalPath		= "F:\inetpub\wwwroot\DOCS_UI"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddDocsUIAppAP"
		}
		
		xWebApplication AddDocsTestingApp
		{
			Website				= "Default Web Site"
			Name				= "DOCS_Testing"
			WebAppPool			= "DocsTesting"
			PhysicalPath		= "F:\inetpub\wwwroot\DOCS_Testing"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddDocsTestingAppAP"
		}
	}
}

Configuration EssServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

        WindowsFeature ADPowerShell
        {
            Ensure = "Present"
            Name = "RSAT-AD-PowerShell"
		}
		
		File IisEssWebServicesPath
		{
			DestinationPath = "F:\inetpub\wwwroot\Ess"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisEssBlobWebServicesPath
		{
			DestinationPath = "F:\inetpub\wwwroot\Ess.Blob"
			Ensure = "Present"
			Type = "Directory"
		}
		
		xWebAppPool AddEssWebServicesAP
		{
			Name							= "EssWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 99999
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
		}

		xWebApplication AddEssWebServices
		{
			Website				= "Default Web Site"
			Name				= "ESS"
			WebAppPool			= "EssWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP"
		}

		xWebApplication AddEssBlobWebServices
		{
			Website				= "Default Web Site"
			Name				= "Ess.Blob"
			WebAppPool			= "EssWebServices"
			PhysicalPath		= "F:\inetpub\wwwroot\Ess.Blob"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP"
		}
	}
}