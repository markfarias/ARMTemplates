Configuration AnyWebSite
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage

	Node $MachineName
	{
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}
	}
}

Configuration MedchartWebApplication
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage

	Node $MachineName
	{
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}

		File IisRootPath
		{
			DestinationPath = "F:\inetpub\wwwroot\medchart"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = "[xDisk]WebDataDisk"
		}

		File IisMedchartWebAppPath
		{
			DestinationPath = "F:\intepub\wwwroot\medchart\MedchartWeb"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisMebprepPath
		{
			DestinationPath = "F:\intepub\wwwroot\medchart\Mebprep"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisRccbtPath
		{
			DestinationPath = "F:\intepub\wwwroot\medchart\Rccbt"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}
	}
}

Configuration MedchartInternalWebServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage

	Node $MachineName
	{
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}

		File IisRootPath
		{
			DestinationPath = "F:\inetpub\wwwroot\webservices"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = "[xDisk]WebDataDisk"
		}

		File IisMedchartWebServicesPath
		{
			DestinationPath = "F:\intepub\wwwroot\webservices\MedchartWebServices"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}
	}
}

Configuration MedchartExternalWebServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage

	Node $MachineName
	{
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}

		File IisRootPath
		{
			DestinationPath = "F:\inetpub\wwwroot\webservices"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = "[xDisk]WebDataDisk"
		}

		File IisMedchartWebServicesPath
		{
			DestinationPath = "F:\intepub\wwwroot\webservices\MedchartWebServices"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisDenclassSVCPath
		{
			DestinationPath = "F:\intepub\wwwroot\webservices\DenclassWebSvc"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisSrexchangeSVCPath
		{
			DestinationPath = "F:\intepub\wwwroot\webservices\Srexchange"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}
	}
}

Configuration DocsServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage

	Node $MachineName
	{
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}

		File IisRootPath
		{
			DestinationPath = "F:\inetpub\wwwroot\docs"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = "[xDisk]WebDataDisk"
		}

		File IisDocsWsPath
		{
			DestinationPath = "F:\intepub\wwwroot\docs\DOCSWS"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisDocsUiPath
		{
			DestinationPath = "F:\intepub\wwwroot\docs\DOCS_UI"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisDocsTestingPath
		{
			DestinationPath = "F:\intepub\wwwroot\docs\DOCS_Testing"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}
	}

}

Configuration EssServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage

	Node $MachineName
	{
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}

		File IisRootPath
		{
			DestinationPath = "F:\inetpub\wwwroot\ess"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = "[xDisk]WebDataDisk"
		}

		File IisMedchartEssMainPath
		{
			DestinationPath = "F:\intepub\wwwroot\ess\Ess"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisDocsEssBlobPath
		{
			DestinationPath = "F:\intepub\wwwroot\ess\Ess.Blob"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}
	}

}