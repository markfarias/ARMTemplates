Configuration AnyWebServer
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, ComputerManagementDsc

	Node $MachineName
	{
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}
		
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}
	}
}

Configuration MedchartWebApplication
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}
		
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}

		File IisRootPath
		{
			DestinationPath = "C:\inetpub\wwwroot\medchart"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisMedchartWebAppPath
		{
			DestinationPath = "C:\inetpub\wwwroot\medchart\MedchartWeb"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisMebprepPath
		{
			DestinationPath = "C:\inetpub\wwwroot\medchart\Mebprep"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisRccbtPath
		{
			DestinationPath = "C:\inetpub\wwwroot\medchart\Rccbt"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}
		
		xWebAppPool AddMedchartWebAP
		{
			Name							= "MedchartWeb"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}
		
		xWebAppPool AddMebprepAP
		{
			Name							= "Mebprep"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}

		xWebAppPool AddRccbtAP
		{
			Name							= "Rccbt"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Classic"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'NetworkService'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}

		xWebApplication AddMedchartWebApplication
		{
			Website				= "Default Web Site"
			Name				= "MedchartWeb"
			WebAppPool			= "MedchartWeb"
			PhysicalPath		= "C:\inetpub\wwwroot\medchart\MedchartWeb"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebAP"
		}
		
		xWebApplication AddMebprepWebApplication
		{
			Website				= "Default Web Site"
			Name				= "Mebprep"
			WebAppPool			= "Mebprep"
			PhysicalPath		= "C:\inetpub\wwwroot\medchart\Mebprep"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMebprepAP"
		}
		
		xWebApplication AddRccbtApplication
		{
			Website				= "Default Web Site"
			Name				= "Rccbt"
			WebAppPool			= "Rccbt"
			PhysicalPath		= "C:\inetpub\wwwroot\medchart\Rccbt"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddRccbtAP"
		}
	}
}

Configuration MedchartInternalWebServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}
		
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}

		File IisRootPath
		{
			DestinationPath = "C:\inetpub\wwwroot\webservices"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisMedchartWebServicesPath
		{
			DestinationPath = "C:\inetpub\wwwroot\webservices\MedchartWebServices"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}
		
		xWebAppPool AddMedchartWebServicesAP
		{
			Name							= "MedchartWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}

		xWebApplication AddMedchartWebServices
		{
			Website				= "Default Web Site"
			Name				= "MedchartWebServices"
			WebAppPool			= "MedchartWebServices"
			PhysicalPath		= "C:\inetpub\wwwroot\webservices\MedchartWebServices"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebServicesAP"
		}	
	}
}

Configuration MedchartExternalWebServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}
		
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}

		File IisRootPath
		{
			DestinationPath = "C:\inetpub\wwwroot\webservices"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisMedchartWebServicesPath
		{
			DestinationPath = "C:\inetpub\wwwroot\webservices\MedchartWebServices"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}
		
		File IisDenclassSVCPath
		{
			DestinationPath = "C:\inetpub\wwwroot\webservices\DenclassWebSvc"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisSrexchangeSVCPath
		{
			DestinationPath = "C:\inetpub\wwwroot\webservices\Srexchange"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		xWebAppPool AddMedchartWebServicesAP
		{
			Name							= "MedchartWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}
		
		xWebAppPool AddDenclassWebSvcAP
		{
			Name							= "DenclassWebSvc"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $true
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Classic"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'NetworkService'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}
		
		xWebAppPool AddSrexchangeAP
		{
			Name							= "Srexchange"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'NetworkService'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}

		xWebApplication AddMedchartWebServices
		{
			Website				= "Default Web Site"
			Name				= "MedchartWebServices"
			WebAppPool			= "MedchartWebServices"
			PhysicalPath		= "C:\inetpub\wwwroot\webservices\MedchartWebServices"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddMedchartWebServicesAP"
		}
		
		xWebApplication AddDenclassWebServices
		{
			Website				= "Default Web Site"
			Name				= "DenclassWebSvc"
			WebAppPool			= "DenclassWebSvc"
			PhysicalPath		= "C:\inetpub\wwwroot\webservices\DenclassWebSvc"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddDenclassWebSvcAP"
		}
		
		xWebApplication AddSrexchangeWebServices
		{
			Website				= "Default Web Site"
			Name				= "Srexchange"
			WebAppPool			= "Srexchange"
			PhysicalPath		= "C:\inetpub\wwwroot\webservices\Srexchange"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddSrexchangeAP"
		}
	}
}

Configuration DocsServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}
		
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}

		File IisRootPath
		{
			DestinationPath = "C:\inetpub\wwwroot\docs"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisDocsWebServicesPath
		{
			DestinationPath = "C:\inetpub\wwwroot\docs\DOCSWS"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}
		
		File IisDocsUIAppPath
		{
			DestinationPath = "C:\inetpub\wwwroot\docs\DOCS_UI"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisDocsTestingAppPath
		{
			DestinationPath = "C:\inetpub\wwwroot\docs\DOCS_Testing"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		
		xWebAppPool AddDocsWebServicesAP
		{
			Name							= "DocsWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}
		
		xWebAppPool AddDocsUIAppAP
		{
			Name							= "DocsUI"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}
		
		xWebAppPool AddDocsTestingAppAP
		{
			Name							= "DocsTesting"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "OnDemand"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Terminate'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}

		xWebApplication AddDocsWebServices
		{
			Website				= "Default Web Site"
			Name				= "DOCSWS"
			WebAppPool			= "DocsWebServices"
			PhysicalPath		= "C:\inetpub\wwwroot\docs\DOCSWS"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddDocsWebServicesAP"
		}
		
		xWebApplication AddDocsUIApp
		{
			Website				= "Default Web Site"
			Name				= "DOCS_UI"
			WebAppPool			= "DocsUI"
			PhysicalPath		= "C:\inetpub\wwwroot\docs\DOCS_UI"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddDocsUIAppAP"
		}
		
		xWebApplication AddDocsTestingApp
		{
			Website				= "Default Web Site"
			Name				= "DOCS_Testing"
			WebAppPool			= "DocsTesting"
			PhysicalPath		= "C:\inetpub\wwwroot\docs\DOCS_Testing"
			Ensure				= "Present"
			DependsOn			= "[xWebAppPool]AddDocsTestingAppAP"
		}
	}
}

Configuration EssServices
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xStorage, xWebAdministration, ComputerManagementDsc
	
	Node $MachineName
	{
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}
		
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}

		#Install ASP.NET 4.5
		WindowsFeature ASP45
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}

		#Install IIS Management Console
		WindowsFeature WebServerManagementConsole
		{
			Ensure = "Present"
			Name = "Web-Mgmt-Console"
		}

		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}

		File IisRootPath
		{
			DestinationPath = "C:\inetpub\wwwroot\ess"
			Ensure = "Present"
			Type = "Directory"
		}

		File IisEssWebServicesPath
		{
			DestinationPath = "C:\inetpub\wwwroot\ess\Ess"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}

		File IisEssBlobWebServicesPath
		{
			DestinationPath = "C:\inetpub\wwwroot\ess\Ess.Blob"
			Ensure = "Present"
			Type = "Directory"
			DependsOn = '[File]IisRootPath'
		}
		
		xWebAppPool AddEssWebServicesAP
		{
			Name							= "EssWebServices"
			Ensure							= "Present"
			State							= "Started"
			autoStart						= $true
			enable32BitAppOnWin64			= $false
            enableConfigurationOverride		= $true
            managedPipelineMode				= "Integrated"
            managedRuntimeVersion			= "v4.0"
            startMode                       = "AlwaysRunning"
            queueLength                     = 1000
            cpuAction                       = "KillW3wp"
            cpuLimit                        = 95000
            cpuResetInterval                = (New-TimeSpan -Minutes 1).ToString()
            cpuSmpAffinitized               = $false
            cpuSmpProcessorAffinityMask     = 4294967295
            cpuSmpProcessorAffinityMask2    = 4294967295
            identityType                    = 'ApplicationPoolIdentity'
            idleTimeout                     = (New-TimeSpan -Minutes 20).ToString()
            idleTimeoutAction               = 'Suspend'
            loadUserProfile                 = $false
            logEventOnProcessModel          = 'IdleTimeout'
            logonType                       = 'LogonBatch'
            manualGroupMembership           = $false
            maxProcesses                    = 1
            pingingEnabled                  = $true
            pingInterval                    = (New-TimeSpan -Seconds 30).ToString()
            pingResponseTime                = (New-TimeSpan -Seconds 90).ToString()
            setProfileEnvironment           = $false
            shutdownTimeLimit               = (New-TimeSpan -Seconds 90).ToString()
            startupTimeLimit                = (New-TimeSpan -Seconds 90).ToString()
            orphanActionExe                 = ''
            orphanActionParams              = ''
            orphanWorkerProcess             = $false
            loadBalancerCapabilities        = 'HttpLevel'
            rapidFailProtection             = $true
            rapidFailProtectionInterval     = (New-TimeSpan -Minutes 1).ToString()
            rapidFailProtectionMaxCrashes   = 5
            autoShutdownExe                 = 'C:\Windows\System32\iisreset.exe'
            autoShutdownParams              = ''
            disallowOverlappingRotation     = $false
            disallowRotationOnConfigChange  = $false
            logEventOnRecycle               = 'Time,Requests,Schedule,Memory,IsapiUnhealthy,OnDemand,ConfigChange,PrivateMemory'
            restartMemoryLimit              = 0
            restartPrivateMemoryLimit       = 0
            restartRequestsLimit            = 0
            restartTimeLimit                = (New-TimeSpan -Minutes 0).ToString()
            restartSchedule                 = "00:00:00"
			DependsOn						= "[WindowsFeature]ASP45"
		}

		xWebApplication AddEssWebServices
		{
			Website				= "Default Web Site"
			Name				= "ESS"
			WebAppPool			= "EssWebServices"
			PhysicalPath		= "C:\inetpub\wwwroot\ess\Ess"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP"
		}

		xWebApplication AddEssBlobWebServices
		{
			Website				= "Default Web Site"
			Name				= "Ess.Blob"
			WebAppPool			= "EssWebServices"
			PhysicalPath		= "C:\inetpub\wwwroot\ess\Ess.Blob"
			Ensure				= "Present"
			PreloadEnabled      = $true
			DependsOn			= "[xWebAppPool]AddEssWebServicesAP"
		}
	}
}