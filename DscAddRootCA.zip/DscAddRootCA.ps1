﻿configuration RootCertificateAuthorityDSC
{
	param
	(
		[Parameter(Mandatory)]
		[String]$CAType,

		[Parameter(Mandatory)]
		[String]$CACommonName,
		
		[Parameter(Mandatory)]
		[String]$CryptoProviderName,

		[Parameter(Mandatory)]
		[Int]$KeyLength,

		[Parameter(Mandatory)]
		[String]$HashAlgorithmName,

		[Parameter(Mandatory)]
		[Int]$ValidityPeriodUnits,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$AdminCredentials,

		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, ActiveDirectoryCSDsc, ComputerManagementDsc

	Node $AllNodes.Where{$_.Role -eq "Root CA"}.Nodename
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyAndAutoCorrect'
			RebootNodeIfNeeded = $true
			ActionAfterReboot = 'ContinueConfiguration'
			AllowModuleOverwrite = $true
		}

		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

		File CertDatabaseDirectory
		{
			DestinationPath = "F:\CertLog"
			Ensure = "Present"
			Type = "Directory"
		}

		WindowsFeature ADCSCertAuthority
        {
            Ensure = 'Present'
            Name   = 'ADCS-Cert-Authority'
        }

		WindowsFeature RSAT-ADCS
		{
			Ensure		= 'Present'
			Name		= 'RSAT-ADCS'
			DependsOn	= '[WindowsFeature]ADCSCertAuthority'
		}

		WindowsFeature RSAT-ADCS-Management
		{
			Ensure		= 'Present'
			Name		= 'RSAT-ADCS-Mgmt'
			DependsOn	= '[WindowsFeature]ADCSCertAuthority'
		}

		AdcsCertificationAuthority CertificateAuthority
        {
            IsSingleInstance	= 'Yes'
            Ensure				= 'Present'
            Credential			= $AdminCredentials
            CAType				= $CAType
			CACommonName		= $CACommonName
			CryptoProviderName	= $CryptoProviderName
			KeyLength			= $KeyLength
			HashAlgorithmName	= $HashAlgorithmName
			ValidityPeriod		= 'Years'
			ValidityPeriodUnits	= $ValidityPeriodUnits
            DependsOn			= '[WindowsFeature]ADCSCertAuthority'
        }
	}
}
