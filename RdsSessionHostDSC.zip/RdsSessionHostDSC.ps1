Configuration EnableRdsSessionHost
{
	param (
		[string]$MachineName = $env:COMPUTERNAME
	)
	
	Import-DscResource -ModuleName PSDesiredStateConfiguration, ComputerManagementDsc, xNetworking
	
	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
		}
		
		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

		xFirewall FirewallRuleForGWRDSH
        {
            Direction = "Inbound"
            Name = "Firewall-GW-RDSH-TCP-In"
            DisplayName = "Firewall-GW-RDSH-TCP-In"
            Description = "Inbound rule for CB to allow TCP traffic for configuring GW and RDSH machines during deployment."
            Group = "Connection Broker"
            Enabled = "True"
            Action = "Allow"
            Protocol = "TCP"
            LocalPort = "5985"
            Ensure = "Present"
        }

		WindowsFeature RemoteDesktopSessionHost
		{
			Ensure = "Present"
			Name = "RDS-RD-Server"
		}
	}
}