﻿configuration PrimaryDomainControllerDSC
{
	param
	(
		[Parameter(Mandatory)]
		[String]$DomainName,

		[Parameter(Mandatory)]
		[String]$DomainDnsName,
		
		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$AdminCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SafeModeCredentials,

		[Parameter(Mandatory)]
		[String]$NU_UserName,

		[Parameter(Mandatory)]
		[String]$NU_GivenName,

		[Parameter(Mandatory)]
		[String]$NU_Surname,

		[Parameter(Mandatory)]
		[String]$NU_PrincipalName,

		[Parameter(Mandatory)]
		[String]$DomainController,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$NewDomainAdminCredentials,

		[string]$MachineName = $env:COMPUTERNAME,

		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, ActiveDirectoryDsc, ComputerManagementDsc

	Node $AllNodes.Where{$_.Role -eq "Primary DC"}.Nodename
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyAndAutoCorrect'
			RebootNodeIfNeeded = $true
			ActionAfterReboot = 'ContinueConfiguration'
			AllowModuleOverwrite = $true
		}

		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

		WindowsFeature DNS
		{
			Ensure = "Present"
			Name = "DNS"
		}

		WindowsFeature DnsTools
		{
			Ensure = "Present"
			Name = "RSAT-DNS-Server"
			DependsOn = "[WindowsFeature]DNS"
		}

		Script script1
		{
			SetScript = {
				Set-DnsServerDiagnostics -All $true
				Write-Verbose -Verbose "Enabling DNS client diagnostics"
			}
			GetScript = { @{}}
			TestScript = { $false}
			DependsOn = "[WindowsFeature]DNS"
		}

		WindowsFeature ADDSInstall
		{
			Ensure = "Present"
			Name = "AD-Domain-Services"
		}

		WindowsFeature ADAdminCenter
		{
			Ensure = "Present"
			Name = "RSAT-AD-AdminCenter"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		WindowsFeature ADDSTools
		{
			Ensure = "Present"
			Name = "RSAT-ADDS-Tools"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		WindowsFeature ADDSPowerShell
		{
			Ensure = "Present"
			Name = "RSAT-AD-PowerShell"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		WindowsFeature GroupPolicyMgt
		{
			Ensure = "Present"
			Name = "GPMC"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		File ActiveDirectoryNTDSFolder
		{
			DestinationPath = "F:\NTDS"
			Ensure = "Present"
			Type = "Directory"
		}

		File ActiveDirectorySysvolFolder
		{
			DestinationPath = "F:\SYSVOL"
			Ensure = "Present"
			Type = "Directory"
		}
		
		ADDomain PrimaryDC
		{
			DomainName = $DomainDnsName
			Credential = $AdminCredentials
			SafemodeAdministratorPassword = $SafeModeCredentials
			ForestMode = 'WinThreshold'
			DatabasePath = "F:\NTDS"
			LogPath = "F:\NTDS"
			SysvolPath = "F:\SYSVOL"
			DependsOn = "[WindowsFeature]ADDSInstall", "[File]ActiveDirectoryNTDSFolder", "[File]ActiveDirectorySysvolFolder"
		}

		ADUser DomainAdminAlternate
		{
			Ensure = 'Present'
			UserName = $NU_UserName
			GivenName = $NU_GivenName
			Surname = $NU_Surname
			UserPrincipalName = $NU_PrincipalName
			Password = $NewDomainAdminCredentials
			DomainName = $DomainDnsName
			DomainController = $DomainController
			ChangePasswordAtLogon = $false
			DependsOn = '[ADDomain]PrimaryDC'
		}

		ADGroup DomainAdminsAddNewUser
		{
			GroupName = 'Domain Admins'
			GroupScope = 'Global'
			Category = 'Security'
			Ensure = 'Present'
			DomainController = $DomainController
			MembersToInclude = @($NU_UserName,$AdminCredentials.UserName)
			DependsOn = "[ADUser]DomainAdminAlternate"
		}

		ADGroup EnterpriseAdminsAddNewUser
		{
			GroupName = 'Enterprise Admins'
			GroupScope = 'Universal'
			Category = 'Security'
			Ensure = 'Present'
			DomainController = $DomainController
			MembersToInclude = @($NU_UserName,$AdminCredentials.UserName)
			DependsOn = "[ADUser]DomainAdminAlternate"
		}

	}
}
