﻿configuration PrimaryDomainControllerDSC
{
	param
	(
		[Parameter(Mandatory)]
		[String]$DomainName,

		[Parameter(Mandatory)]
		[String]$DomainDnsName,
		
		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$AdminCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$SafeModeCredentials,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$NewDomainAdminCredentials,

		[string]$MachineName = $env:COMPUTERNAME,

		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration, ActiveDirectoryDsc, xNetworking, xStorage, ComputerManagementDsc

	#[System.Management.Automation.PSCredential]$DomainCredentials = New-Object System.Management.Automation.PSCredential (".\$($AdminCredentials.UserName)", $AdminCredentials.Password)
	$Interface = Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
	$InterfaceAlias = $($Interface.Name)

	Node $AllNodes.NodeName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyAndAutoCorrect'
			RebootNodeIfNeeded = $true
			ActionAfterReboot = 'ContinueConfiguration'
			AllowModuleOverwrite = $true
		}

		#Change Server Time to Eastern Time Zone
		TimeZone SetTimeZone
		{
			IsSingleInstance = "Yes"
			TimeZone = "Eastern Standard Time"
		}

		xDHCPClient DisableDhcp
        {
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
            State          = 'Disabled'
        }

		WindowsFeature DNS
		{
			Ensure = "Present"
			Name = "DNS"
		}

		WindowsFeature DnsTools
		{
			Ensure = "Present"
			Name = "RSAT-DNS-Server"
			DependsOn = "[WindowsFeature]DNS"
		}

		xDnsServerAddress DnsServerAddress
		{
			Address = '127.0.0.1'
			InterfaceAlias = $InterfaceAlias
			AddressFamily = 'IPv4'
			Validate = $true
			DependsOn = "[WindowsFeature]DNS"
		}

		Script script1
		{
			SetScript = {
				Set-DnsServerDiagnostics -All $true
				Write-Verbose -Verbose "Enabling DNS client diagnostics"
			}
			GetScript = { @{}}
			TestScript = { $false}
			DependsOn = "[WindowsFeature]DNS"
		}

		xWaitforDisk Disk2
        {
            DiskId = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk ADDataDisk
        {
            DiskId = 2
            DriveLetter = 'F'
			FSLabel = 'DataDisk1'
            DependsOn = "[xWaitforDisk]Disk2"
        }

		WindowsFeature ADDSInstall
		{
			Ensure = "Present"
			Name = "AD-Domain-Services"
			DependsOn = "[xDisk]ADDataDisk"
		}

		WindowsFeature ADAdminCenter
		{
			Ensure = "Present"
			Name = "RSAT-AD-AdminCenter"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		WindowsFeature ADDSTools
		{
			Ensure = "Present"
			Name = "RSAT-ADDS-Tools"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		WindowsFeature ADDSPowerShell
		{
			Ensure = "Present"
			Name = "RSAT-AD-PowerShell"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		WindowsFeature GroupPolicyMgt
		{
			Ensure = "Present"
			Name = "GPMC"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		ADDomain FirstDS
		{
			DomainName = $DomainDnsName
			DomainNetBiosName = $DomainName
			Credential = $AdminCredentials
			SafemodeAdministratorPassword = $SafeModeCredentials
			ForestMode = 'WinThreshold'
			DatabasePath = "F:\NTDS"
			LogPath = "F:\NTDS"
			SysvolPath = "F:\SYSVOL"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		ADUser AdminUserMadison
		{
			Ensure = 'Present'
			UserName = $NewDomainAdminCredentials.UserName
			Password = $NewDomainAdminCredentials
			DomainName = $DomainDnsName
			ChangePasswordAtLogon = $false
			Credential = $NewDomainAdminCredentials
			DependsOn = '[ADDomain]FirstDS'
		}

		ADGroup DomainAdmins
		{
			GroupName = 'Domain Admins'
			GroupScope = 'Global'
			Category = 'Security'
			Ensure = 'Present'
			MembersToInclude = @($NewDomainAdminCredentials.UserName)
			Credential = $NewDomainAdminCredentials
			DependsOn = "[ADUser]AdminUserMadison"
		}

		ADGroup EnterpriseAdmins
		{
			GroupName = 'Enterprise Admins'
			GroupScope = 'Universal'
			Category = 'Security'
			Ensure = 'Present'
			MembersToInclude = @($NewDomainAdminCredentials.UserName)
			Credential = $NewDomainAdminCredentials
			DependsOn = "[ADUser]AdminUserMadison"
		}

		PendingReboot RebootAfterPromotion
		{
			Name = 'RebootAfterPromotion'
			DependsOn = '[ADDomain]FirstDS'
		}
	}
}
