﻿configuration BackupDomainControllerDSC
{
	param
	(
		[Parameter(Mandatory)]
		[String]$DNSServer,

		[Parameter(Mandatory)]
        [String]$DomainName,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$AdminCredentials,

		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName xActiveDirectory, xNetworking, PSDesiredStateConfiguration

	[System.Management.Automation.PSCredential]$DomainCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCredentials.UserName)", $AdminCredentials.Password)
	$Interface = Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
	$InterfaceAlias = $($Interface.Name)

	Node localhost
	{
		LocalConfigurationManager
		{
			ConfigurationMode = "ApployOnly"
			RebootNodeIfNeeded = $true
		}

		WindowsFeature ADDSInstall
		{
			Ensure = "Present"
			Name = "AD-Domain-Services"
		}

		WindowsFeature ADAdminCenter
		{
			Ensure = "Present"
			Name = "RSAT-AD-AdminCenter"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		WindowsFeature ADDSTools
		{
			Ensure = "Present"
			Name = "RSAT-ADDS-Tools"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		xDnsServerAddress DnsServerAddress
		{
			Address = $DNSServer
			InterfaceAlias = $InterfaceAlias
			AddressFamily = "IPv4"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		xWaitForADDomain DscForestWait
		{
			DomainName = $DomainName
			DomainUserCredential = $DomainCredentials
			RetryCount = $RetryCount
			RetryIntervalSec = $RetryIntervalSec
			DependsOn = "[WindowsFeature]ADDInstall"
		}

		xADDomainController BDC
		{
			DomainName = $DomainName
			DomainAdministratorCredential = $DomainCredentials
			SafemodeAdministratorPassword = $DomainCredentials
			DatabasePath = "C:\Windows\NTDS"
			LogPath = "C:\Windows\NTDS"
			SysvolPath = "C:\Windows\SYSVOL"
			DependsOn = "[xWaitForADDomain]DscForestWait"
		}

		Script script1
		{
			SetScript = 
			{
				$dnsFwdRule = Get-DnsServerForward
				if ($dnsFwdRule)
				{
					Remove-DnsServerForwarder -IPAddress $dnsFwdRule.IPAddress -Force
				}
				Write-Verbose -Verbose "Removing DNS forwarding rule"
			}
			GetScript = { @{} }
			TestScript = { $false }
			DependsOn = "[xADDomainController]BDC"
		}
	}
}
