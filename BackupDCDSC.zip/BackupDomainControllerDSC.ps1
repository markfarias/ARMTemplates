﻿configuration BackupDomainControllerDSC
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,

		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName xStorage, PSDesiredStateConfiguration

	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyAndAutoCorrect'
			RebootNodeIfNeeded = $true
			ActionAfterReboot = 'ContinueConfiguration'
			AllowModuleOverwrite = $true
		}

		xWaitforDisk Disk2
        {
            DiskId = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk ADDataDisk
        {
            DiskId = 2
            DriveLetter = 'F'
			FSLabel = 'DataDisk1'
            DependsOn = "[xWaitforDisk]Disk2"
        }

		WindowsFeature ADDSInstall
		{
			Ensure = "Present"
			Name = "AD-Domain-Services"
			DependsOn = "[xDisk]ADDataDisk"
		}

		WindowsFeature ADAdminCenter
		{
			Ensure = "Present"
			Name = "RSAT-AD-AdminCenter"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		WindowsFeature ADDSTools
		{
			Ensure = "Present"
			Name = "RSAT-ADDS-Tools"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}
	}
}
