﻿configuration BackupDomainControllerDSC
{
	param
	(
		[Parameter(Mandatory)]
        [String]$DomainName,

		[Parameter(Mandatory)]
		[System.Management.Automation.PSCredential]$AdminCredentials,

		[string]$MachineName = $env:COMPUTERNAME,

		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName xActiveDirectory, xStorage, PSDesiredStateConfiguration

	[System.Management.Automation.PSCredential]$DomainCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCredentials.UserName)", $AdminCredentials.Password)

	Node $MachineName
	{
		LocalConfigurationManager
		{
			ConfigurationMode = 'ApplyAndAutoCorrect'
			RebootNodeIfNeeded = $true
			ActionAfterReboot = 'ContinueConfiguration'
			AllowModuleOverwrite = $true
		}

		xWaitforDisk Disk2
        {
            DiskId = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk ADDataDisk
        {
            DiskId = 2
            DriveLetter = 'F'
			FSLabel = 'DataDisk1'
            DependsOn = "[xWaitforDisk]Disk2"
        }

		WindowsFeature ADDSInstall
		{
			Ensure = "Present"
			Name = "AD-Domain-Services"
			DependsOn = "[xDisk]ADDataDisk"
		}

		WindowsFeature ADAdminCenter
		{
			Ensure = "Present"
			Name = "RSAT-AD-AdminCenter"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		WindowsFeature ADDSTools
		{
			Ensure = "Present"
			Name = "RSAT-ADDS-Tools"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		xADDomainController BDC
		{
			DomainName = $DomainName
			DomainAdministratorCredential = $DomainCredentials
			SafemodeAdministratorPassword = $DomainCredentials
			DatabasePath = "F:\NTDS"
			LogPath = "F:\NTDS"
			SysvolPath = "F:\SYSVOL"
			DependsOn = "[WindowsFeature]ADDSInstall"
		}

		Script script1
		{
			SetScript = 
			{
				$dnsFwdRule = Get-DnsServerForward
				if ($dnsFwdRule)
				{
					Remove-DnsServerForwarder -IPAddress $dnsFwdRule.IPAddress -Force
				}
				Write-Verbose -Verbose "Removing DNS forwarding rule"
			}
			GetScript = { @{} }
			TestScript = { $false }
			DependsOn = "[xADDomainController]BDC"
		}
	}
}
