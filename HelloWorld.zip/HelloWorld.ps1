Configuration HelloWorld {

    param(
        [String]
        $username,
        [String]
        $password,
		[String]
		$protectedPwdClear,
		[PSCredential]
		$protectedPwd
    )

    # Import the module that contains the File resource.
    Import-DscResource -ModuleName PsDesiredStateConfiguration

    $secpassword = ConvertTo-SecureString $password -AsPlainText -Force

    $cred = New-Object PSCredential($username, $secpassword)

    # The Node statement specifies which targets to compile MOF files for, when this configuration is executed.
    Node 'localhost' {

        # The File resource can ensure the state of files, or copy them from a source to a destination with persistent updates.
        File HelloWorld {
            DestinationPath = "C:\Temp\HelloWorld.txt"
            Ensure = "Present"
            Contents   = "Cleartext Password:$password | Secure Password:$secpassword | Credential Password: $cred.Password | Protected Pwd String:$protectedPwdClear | Protected Pwd:$protectedPwd"
        }
    }
}