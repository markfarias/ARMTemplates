Configuration HelloWorld {

    param(
        [String]
        $ctusername,
        [String]
        $ctpassword,
		[String]
		$protectedPwdClear,
		[string]
		$protectedPwdClearKv,
		[PSCredential]
		$psCred
    )

    # Import the module that contains the File resource.
    Import-DscResource -ModuleName PsDesiredStateConfiguration

    $secpassword = ConvertTo-SecureString $ctpassword -AsPlainText -Force

    $cred = New-Object PSCredential($ctusername, $secpassword)

    # The Node statement specifies which targets to compile MOF files for, when this configuration is executed.
    Node 'localhost' {

        # The File resource can ensure the state of files, or copy them from a source to a destination with persistent updates.
        File HelloWorld {
            DestinationPath = "C:\Temp\HelloWorld.txt"
            Ensure = "Present"
            Contents   = "Username:$ctusername | Cleartext Password:$ctpassword | Protected Pwd String:$protectedPwdClear | Protected Pwd Kv:$protectedPwdClearKv | Secure Password:$secpassword | Credential Username:$cred.Username | Credential Password: $cred.Password | Azure Credential Username:$psCred.Username | Azure Credential Password:$psCred.Password"
        }
    }
}