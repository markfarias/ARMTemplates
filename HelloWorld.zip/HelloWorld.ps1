Configuration HelloWorld {

    param(
        [String]
        $UidClear,
		[String]
		$PwdClear,
		[String]
		$UidClearKv,
		[String]
		$PwdClearKv,
		[Security.SecureString]
		$ProtectedPwd,
		[PSCredential]
		$psCred
    )

    # Import the module that contains the File resource.
    Import-DscResource -ModuleName PsDesiredStateConfiguration

    $secpassword = ConvertTo-SecureString $PwdClear -AsPlainText -Force
    $cred = New-Object PSCredential($UidClear, $secpassword)
	$credUid = $cred.UserName
	
	$secpwdkv = ConvertTo-SecureString $PwdClearKv -AsPlainText -Force
	$credkv = New-Object PSCredential($UidClearKv, $secpwdkv)
	$credUidKv = $credkv.UserName
	
	$pscreduid = $psCred.UserName

    # The Node statement specifies which targets to compile MOF files for, when this configuration is executed.
    Node $AllNodes.Where{$_.Role -eq "Root CA"}.Nodename 
	{

        # The File resource can ensure the state of files, or copy them from a source to a destination with persistent updates.
        File HelloWorld {
            DestinationPath = "C:\Temp\HelloWorld.txt"
            Ensure = "Present"
            Contents   = "Cleartext Username:$UidClear | Cleartext Password:$PwdClear | Cleartext Username Kv:$UidClearKv | Cleartext Password Kv:$PwdClearKv | Secure String Pwd:$ProtectedPwd | Secure String Pwd Kv:$ProtectedPwdKv | Credential UserName:$credUid | Credential UserName Kv:$credUidKv | Azure Credential UserName:$pscreduid"
        }
    }
}