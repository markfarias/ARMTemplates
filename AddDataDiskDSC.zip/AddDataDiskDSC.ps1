Configuration AddDataDisks
{
	param
	(
		[string]$MachineName = $env:COMPUTERNAME,
		[Int]$RetryCount=20,
		[Int]$RetryIntervalSec=30
	)

	Import-DscResource -ModuleName xStorage, PSDesiredStateConfiguration

	Node $MachineName
	{
		xWaitforDisk DataDisk1
		{
			DiskId = 2
			RetryIntervalSec = $RetryIntervalSec
			RetryCount = $RetryCount
		}

		xDisk WebDataDisk
		{
			DiskId = 2
			DriveLetter = 'F'
			FSLabel = 'DataDisk1'
			DependsOn = "[xWaitforDisk]DataDisk1"
		}
	}
}